package com.email.emaiApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmaiApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
