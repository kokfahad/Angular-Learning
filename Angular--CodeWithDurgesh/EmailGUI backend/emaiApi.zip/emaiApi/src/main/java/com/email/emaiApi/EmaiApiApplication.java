package com.email.emaiApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmaiApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmaiApiApplication.class, args);
	}

}
